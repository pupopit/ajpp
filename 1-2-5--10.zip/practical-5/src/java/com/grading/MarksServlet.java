package com.grading;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Arrays;

@WebServlet("/MarksServlet")
public class MarksServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get parameters from the form
        int[] marks = new int[6];
        int total = 0;
        boolean isPassed = true;
        
        // Get marks for all subjects and calculate total
        for (int i = 0; i < 6; i++) {
            String markParam = request.getParameter("subject" + (i+1));
            marks[i] = Integer.parseInt(markParam);
            total += marks[i];
            
            // Fail condition: any subject less than 35
            if (marks[i] < 35) {
                isPassed = false;
            }
        }
        
        // Overall pass/fail condition (additional check for average)
        double average = total / 6.0;
        if (average < 40) {
            isPassed = false;
        }
        
        // Get the existing session
        HttpSession session = request.getSession(false);
        
        // Store marks and result in session
        session.setAttribute("marks", marks);
        session.setAttribute("total", total);
        session.setAttribute("average", average);
        session.setAttribute("result", isPassed ? "PASS" : "FAIL");
        
        // Redirect to result page
        response.sendRedirect("result.jsp");
    }
}