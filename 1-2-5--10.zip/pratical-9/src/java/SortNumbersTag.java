/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dhruv
 */
package customtags;

import java.io.IOException;
import java.util.Arrays;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

public class SortNumbersTag extends TagSupport {
    private String numbers;
    private String order = "asc"; // Default order

    public void setNumbers(String numbers) {
        this.numbers = numbers;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    @Override
    public int doStartTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
            
            // Convert input string to an array of numbers
            String[] numArray = numbers.split(",");
            int[] intNumbers = new int[numArray.length];

            for (int i = 0; i < numArray.length; i++) {
                intNumbers[i] = Integer.parseInt(numArray[i].trim());
            }

            // Sort the numbers
            Arrays.sort(intNumbers);
            if ("desc".equalsIgnoreCase(order)) {
                for (int i = 0; i < intNumbers.length / 2; i++) {
                    int temp = intNumbers[i];
                    intNumbers[i] = intNumbers[intNumbers.length - 1 - i];
                    intNumbers[intNumbers.length - 1 - i] = temp;
                }
            }

            // Display sorted numbers
            out.print("<p>Sorted Numbers (" + order.toUpperCase() + "): ");
            for (int num : intNumbers) {
                out.print(num + " ");
            }
            out.print("</p>");

        } catch (IOException | NumberFormatException e) {
            throw new JspException("Error in SortNumbersTag", e);
        }
        return SKIP_BODY;
    }
}




